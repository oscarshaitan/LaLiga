package com.oscart.laliga;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import Retro.Team;
import presenter.MainP;

public class Main extends AppCompatActivity implements MainP.MainPresenter {
    private RetroToDBFunctions RTDB;
    private MainP mainP;
    private TeamCellAdapter adapter;
    private GridLayoutManager gridLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RTDB = new RetroToDBFunctions(this);
        mainP = new MainP(this);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        gridLayoutManager = new GridLayoutManager(this,3);
        onConfigurationChanged(getResources().getConfiguration());
        RecyclerView recycler = (RecyclerView)findViewById(R.id.recycler);
        recycler.setLayoutManager(gridLayoutManager);
        adapter = new TeamCellAdapter(height,width,this);
        mainP.getData();

        recycler.setAdapter(adapter);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void getTeamFromDB() {
         adapter.add(RTDB.getTeams());
         adapter.notifyDataSetChanged();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if(newConfig.orientation==Configuration.ORIENTATION_LANDSCAPE){
            gridLayoutManager.setSpanCount(5);
        }
        else {
            gridLayoutManager.setSpanCount(3);
        }
        /*
    public static final int ORIENTATION_LANDSCAPE = 2;
    public static final int ORIENTATION_PORTRAIT = 1;*/
    }

    public void slectLanguage(){
       /* final List<String> Language = new ArrayList<>();
        searchOpt.add("Category");
        searchOpt.add("Keyword (Online only)");
        MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title("Pick a Mode")
                .items(searchOpt)
                .itemsDisabledIndices(!isConnected()?1:-1)
                .positiveText("Ok")
                .choiceWidgetColor(getResources().getColorStateList(R.color.colorPrimary))
                .itemsCallbackSingleChoice(0, new MaterialDialog.ListCallbackSingleChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, View itemView, int which, CharSequence text) {
                        if(dialog.getSelectedIndex()==0){
                            genres.clear();
                            getCats();
                        }
                        else if(dialog.getSelectedIndex()==1){
                            searchOnline();
                        }
                        return false;
                    }
                })
                .show();*/
    }
}
